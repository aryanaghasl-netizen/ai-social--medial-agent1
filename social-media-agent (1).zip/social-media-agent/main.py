"""CLI.   python main.py demo | create | queue | scheduler"""
import argparse
import time
from datetime import timedelta

from app import db, service
from app.scheduler import publish_due, start_scheduler

LINE = "─" * 60


def show(pending: dict):
    print(f"\n{LINE}\n📝 DRAFT for {pending['platform']}  (revision {pending['revisions']})")
    print(f"   {pending['draft']}")
    print(f"   🔍 auto-review: {pending['review_notes']}\n{LINE}")


def cmd_create(args):
    when = None
    thread_id, pending, result = service.start_post(args.topic, args.platform, args.tone, when)
    while pending:
        show(pending)
        ans = input("[a]pprove / [r]evise / [x] reject > ").strip().lower()
        if ans.startswith("a"):
            pending, result = service.submit_decision(thread_id, "approve")
        elif ans.startswith("r"):
            fb = input("feedback > ")
            pending, result = service.submit_decision(thread_id, "revise", fb)
        else:
            pending, result = service.submit_decision(thread_id, "reject")
    print(f"\nStatus: {result['status']}", f"| scheduled for {result.get('scheduled_for')}" if result.get("scheduled_for") else "")


def cmd_demo(_):
    print("🤖 AI Social Media Agent — demo (no API keys needed)\n")
    when = db.iso(db.utcnow() + timedelta(seconds=3))
    thread_id, pending, _ = service.start_post(
        "Launching our open-source LangGraph social media agent", "twitter", "professional", when)
    show(pending)
    print("👤 Human: 'make it shorter and add an emoji'  → REVISE")
    pending, _ = service.submit_decision(thread_id, "revise", "make it shorter and add an emoji")
    show(pending)
    print("👤 Human: looks good → APPROVE")
    _, result = service.submit_decision(thread_id, "approve")
    print(f"\n📅 Scheduled post #{result['post_id']} for {result['scheduled_for']}")
    print("⏳ Waiting for the scheduler (cron job) to pick it up...")
    time.sleep(4)
    for p in publish_due():
        print(f"🚀 Published #{p['id']} on {p['platform']} (external id {p['external_id']})")
    print("\n📬 Final queue:")
    for row in db.list_posts()[:3]:
        print(f"   #{row['id']} [{row['status']}] {row['content']}")
    print("\nSee data/published.log for the 'published' output.")


def cmd_queue(_):
    for row in db.list_posts():
        print(f"#{row['id']} [{row['status']}] {row['platform']} @ {row['scheduled_for']}: {row['content']}")


def cmd_scheduler(_):
    print("Scheduler running (every minute). Ctrl+C to stop.")
    start_scheduler(blocking=True)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("demo").set_defaults(fn=cmd_demo)
    c = sub.add_parser("create")
    c.add_argument("--topic", required=True)
    c.add_argument("--platform", default="twitter", choices=["twitter", "linkedin"])
    c.add_argument("--tone", default="professional")
    c.set_defaults(fn=cmd_create)
    sub.add_parser("queue").set_defaults(fn=cmd_queue)
    sub.add_parser("scheduler").set_defaults(fn=cmd_scheduler)
    a = p.parse_args()
    a.fn(a)
