# 🤖 AI Social Media Agent

An agent that **generates** social posts, **pauses for human approval**, **schedules** approved posts, and **publishes** them via platform APIs — built with **LangGraph**, tool calling, OAuth 2.0 (PKCE) and cron automation.

## Workflow

```mermaid
flowchart LR
    A[generate draft<br/>LLM + tools] --> B[auto_review<br/>char-limit tool]
    B --> C{{human_approval<br/>interrupt}}
    C -- approve --> D[schedule<br/>SQLite queue]
    C -- revise + feedback --> A
    C -- reject --> E[end]
    D --> F[cron job every minute<br/>publish_due]
    F --> G[Twitter / LinkedIn / mock]
```

| Requirement | Where |
|---|---|
| Generate posts | `app/llm.py` (Claude via LangChain, or built-in mock writer when no key) |
| Human approval | `app/graph.py` → `interrupt()` + `Command(resume=...)`; API inbox in `api.py` |
| Schedule | `schedule` node → `app/db.py` queue |
| External platforms | `app/platforms/` (Twitter/X, LinkedIn, mock) |
| OAuth | `app/oauth.py` (Twitter OAuth 2.0 PKCE + refresh) |
| Cron automation | `app/scheduler.py` (APScheduler, every minute) |
| Tool calling | `app/tools.py` (`check_char_limit`, `suggest_hashtags`, `get_best_posting_time`) |

## Quick start (demo works with no API keys)

```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                   # optional: add ANTHROPIC_API_KEY
python main.py demo
```

The demo drafts a post → a "human" asks for changes → agent revises → "human" approves → post is scheduled → the scheduler publishes it. Output lands in `data/published.log` (`PUBLISH_MODE=mock`).

Run the tests: `pytest -q`

## Try it yourself

**Interactive CLI**
```bash
python main.py create --topic "We just shipped v1.0" --platform twitter
python main.py queue
python main.py scheduler        # cron worker (publishes due posts every minute)
```

**REST API (approval inbox)**
```bash
uvicorn api:app --reload
curl -X POST localhost:8000/posts -H 'content-type: application/json' \
     -d '{"topic":"We just shipped v1.0","platform":"twitter"}'      # -> thread_id + draft
curl localhost:8000/posts/pending
curl -X POST localhost:8000/posts/<thread_id>/decision -H 'content-type: application/json' \
     -d '{"action":"revise","feedback":"add an emoji"}'
curl -X POST localhost:8000/posts/<thread_id>/decision -H 'content-type: application/json' \
     -d '{"action":"approve"}'
curl localhost:8000/queue
```
Interactive docs at http://localhost:8000/docs.

## Going live

1. Create a Twitter/X app (OAuth 2.0, enable "Read and write"), add the callback `http://localhost:8000/auth/twitter/callback`, and put `TWITTER_CLIENT_ID/SECRET` in `.env`.
2. Set `PUBLISH_MODE=live`, start `uvicorn api:app`, visit `/auth/twitter/login` once to connect. Tokens are stored in SQLite and refreshed automatically.
3. LinkedIn: set `LINKEDIN_ACCESS_TOKEN` and `LINKEDIN_AUTHOR_URN`.

Prefer system cron over APScheduler? Use: `* * * * * cd /path/to/repo && .venv/bin/python -c "from app.scheduler import publish_due; publish_due()"`

## Notes / next steps
- The approval state uses LangGraph's in-memory checkpointer, so pending drafts are lost on restart. For production switch to `SqliteSaver`/`PostgresSaver` in `app/graph.py`.
- OAuth `state` values are kept in memory; use Redis/DB when running multiple workers.
- Ideas: Slack/Telegram approval buttons, image generation node, analytics node, more platforms.

## Structure
```
main.py            CLI (demo / create / queue / scheduler)
api.py             FastAPI approval inbox + OAuth routes
app/graph.py       LangGraph workflow
app/tools.py       tool-calling functions
app/llm.py         LLM writer (+ mock)
app/oauth.py       Twitter OAuth2 PKCE
app/platforms/     publishers
app/scheduler.py   cron job
app/db.py          SQLite queue + token store
tests/             end-to-end workflow test
```
