import os

import requests

from .base import Publisher


class LinkedInPublisher(Publisher):
    name = "linkedin"

    def publish(self, content: str) -> str:
        token, author = os.getenv("LINKEDIN_ACCESS_TOKEN"), os.getenv("LINKEDIN_AUTHOR_URN")
        if not token or not author:
            raise RuntimeError("Set LINKEDIN_ACCESS_TOKEN and LINKEDIN_AUTHOR_URN")
        body = {
            "author": author,
            "lifecycleState": "PUBLISHED",
            "specificContent": {"com.linkedin.ugc.ShareContent": {
                "shareCommentary": {"text": content}, "shareMediaCategory": "NONE"}},
            "visibility": {"com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"},
        }
        r = requests.post("https://api.linkedin.com/v2/ugcPosts", json=body, timeout=15, headers={
            "Authorization": f"Bearer {token}", "X-Restli-Protocol-Version": "2.0.0"})
        r.raise_for_status()
        return r.headers.get("x-restli-id", r.json().get("id", "unknown"))
