import requests

from .. import oauth
from .base import Publisher


class TwitterPublisher(Publisher):
    name = "twitter"

    def publish(self, content: str) -> str:
        r = requests.post(
            "https://api.twitter.com/2/tweets",
            json={"text": content},
            headers={"Authorization": f"Bearer {oauth.get_valid_token()}"},
            timeout=15,
        )
        r.raise_for_status()
        return r.json()["data"]["id"]
