import uuid
from pathlib import Path

from .. import config
from ..db import iso, utcnow
from .base import Publisher


class MockPublisher(Publisher):
    """Safe demo publisher: appends to data/published.log instead of calling a real API."""
    name = "mock"

    def __init__(self, platform: str = "mock"):
        self.platform = platform

    def publish(self, content: str) -> str:
        Path(config.PUBLISHED_LOG).parent.mkdir(parents=True, exist_ok=True)
        pid = uuid.uuid4().hex[:10]
        with open(config.PUBLISHED_LOG, "a", encoding="utf-8") as f:
            f.write(f"[{iso(utcnow())}] ({self.platform}) id={pid} :: {content}\n")
        return pid
