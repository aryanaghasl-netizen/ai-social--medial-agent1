from .. import config
from .base import Publisher
from .mock import MockPublisher


def get_publisher(platform: str) -> Publisher:
    if config.PUBLISH_MODE != "live":
        return MockPublisher(platform)
    if platform == "twitter":
        from .twitter import TwitterPublisher
        return TwitterPublisher()
    if platform == "linkedin":
        from .linkedin import LinkedInPublisher
        return LinkedInPublisher()
    raise ValueError(f"Unsupported platform: {platform}")
