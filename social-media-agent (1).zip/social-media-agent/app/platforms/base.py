class Publisher:
    name = "base"

    def publish(self, content: str) -> str:
        """Publish content and return the external post id."""
        raise NotImplementedError
