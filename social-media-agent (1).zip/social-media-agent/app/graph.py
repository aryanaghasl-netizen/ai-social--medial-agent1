"""LangGraph workflow:

START -> generate -> auto_review -> human_approval (INTERRUPT)
            ^                              |
            |-------- revise --------------+-- approve --> schedule -> END
                                           +-- reject  --> END
"""
import json
from typing import TypedDict

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import interrupt

from . import config, db
from .llm import generate_draft
from .tools import check_char_limit, get_best_posting_time


class PostState(TypedDict, total=False):
    topic: str
    platform: str
    tone: str
    draft: str
    review_notes: str
    feedback: str
    decision: str          # approve | revise | reject
    revisions: int
    scheduled_for: str
    post_id: int
    status: str


def generate(state: PostState) -> dict:
    draft = generate_draft(
        state["topic"], state["platform"], state.get("tone", "professional"),
        feedback=state.get("feedback", ""), previous=state.get("draft", ""),
    )
    return {"draft": draft, "status": "drafted"}


def auto_review(state: PostState) -> dict:
    """Automated check using a tool before a human sees the draft."""
    res = json.loads(check_char_limit.invoke({"text": state["draft"], "platform": state["platform"]}))
    draft, note = state["draft"], f"length {res['length']}/{res['limit']} OK"
    if not res["ok"]:
        draft = draft[: res["limit"] - 1] + "…"
        note = f"was {res['length']} chars (limit {res['limit']}); auto-trimmed"
    return {"draft": draft, "review_notes": note}


def human_approval(state: PostState) -> dict:
    """Pauses the graph until a human responds (human-in-the-loop)."""
    reply = interrupt({
        "draft": state["draft"],
        "platform": state["platform"],
        "review_notes": state.get("review_notes", ""),
        "revisions": state.get("revisions", 0),
    })
    action = reply.get("action", "reject")
    update = {"decision": action, "feedback": reply.get("feedback", "")}
    if reply.get("edited_draft"):               # human edited the text directly
        update["draft"] = reply["edited_draft"]
    if action == "revise":
        update["revisions"] = state.get("revisions", 0) + 1
    return update


def route_after_approval(state: PostState) -> str:
    if state["decision"] == "approve":
        return "schedule"
    if state["decision"] == "revise" and state.get("revisions", 0) <= config.MAX_REVISIONS:
        return "generate"
    return "rejected"


def schedule(state: PostState) -> dict:
    when = state.get("scheduled_for") or get_best_posting_time.invoke({"platform": state["platform"]})
    post_id = db.add_post(state["platform"], state["draft"], when)
    return {"post_id": post_id, "scheduled_for": when, "status": "scheduled"}


def rejected(state: PostState) -> dict:
    return {"status": "rejected"}


def build_graph(checkpointer=None):
    g = StateGraph(PostState)
    g.add_node("generate", generate)
    g.add_node("auto_review", auto_review)
    g.add_node("human_approval", human_approval)
    g.add_node("schedule", schedule)
    g.add_node("rejected", rejected)

    g.add_edge(START, "generate")
    g.add_edge("generate", "auto_review")
    g.add_edge("auto_review", "human_approval")
    g.add_conditional_edges("human_approval", route_after_approval,
                            {"schedule": "schedule", "generate": "generate", "rejected": "rejected"})
    g.add_edge("schedule", END)
    g.add_edge("rejected", END)
    return g.compile(checkpointer=checkpointer or MemorySaver())
