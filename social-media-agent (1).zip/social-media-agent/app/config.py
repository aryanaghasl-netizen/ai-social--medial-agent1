import os

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:  # dotenv is optional
    pass

DB_PATH = os.getenv("DB_PATH", "data/agent.db")
PUBLISH_MODE = os.getenv("PUBLISH_MODE", "mock")          # mock | live
LLM_MODEL = os.getenv("LLM_MODEL", "claude-sonnet-5-5")
MAX_REVISIONS = int(os.getenv("MAX_REVISIONS", "3"))
PUBLISHED_LOG = os.getenv("PUBLISHED_LOG", "data/published.log")
