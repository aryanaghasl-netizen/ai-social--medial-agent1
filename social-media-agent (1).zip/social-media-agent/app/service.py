"""Thin wrapper used by the CLI and the API: start a workflow, submit a human decision."""
import uuid

from langgraph.types import Command

from .graph import build_graph

graph = build_graph()
PENDING: dict[str, dict] = {}   # thread_id -> interrupt payload awaiting approval


def _payload(result: dict):
    intr = result.get("__interrupt__")
    return intr[0].value if intr else None


def start_post(topic: str, platform: str = "twitter", tone: str = "professional",
               scheduled_for: str | None = None) -> tuple[str, dict | None, dict]:
    thread_id = str(uuid.uuid4())[:8]
    state = {"topic": topic, "platform": platform, "tone": tone, "revisions": 0}
    if scheduled_for:
        state["scheduled_for"] = scheduled_for
    result = graph.invoke(state, {"configurable": {"thread_id": thread_id}})
    pending = _payload(result)
    if pending:
        PENDING[thread_id] = pending
    return thread_id, pending, result


def submit_decision(thread_id: str, action: str, feedback: str = "",
                    edited_draft: str | None = None) -> tuple[dict | None, dict]:
    reply = {"action": action, "feedback": feedback}
    if edited_draft:
        reply["edited_draft"] = edited_draft
    result = graph.invoke(Command(resume=reply), {"configurable": {"thread_id": thread_id}})
    pending = _payload(result)
    if pending:
        PENDING[thread_id] = pending
    else:
        PENDING.pop(thread_id, None)
    return pending, result
