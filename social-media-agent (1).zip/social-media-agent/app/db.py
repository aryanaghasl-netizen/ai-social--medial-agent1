"""SQLite storage: the post queue + OAuth tokens."""
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from . import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    platform TEXT NOT NULL,
    content TEXT NOT NULL,
    scheduled_for TEXT NOT NULL,          -- ISO-8601 UTC
    status TEXT NOT NULL DEFAULT 'scheduled',  -- scheduled | published | failed
    external_id TEXT,
    error TEXT,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS tokens (
    platform TEXT PRIMARY KEY,
    data TEXT NOT NULL
);
"""


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat(timespec="seconds")


def _conn() -> sqlite3.Connection:
    Path(config.DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(config.DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    return conn


def add_post(platform: str, content: str, scheduled_for: str) -> int:
    with _conn() as c:
        cur = c.execute(
            "INSERT INTO posts (platform, content, scheduled_for, created_at) VALUES (?,?,?,?)",
            (platform, content, scheduled_for, iso(utcnow())),
        )
        return cur.lastrowid


def due_posts(now: datetime | None = None) -> list[sqlite3.Row]:
    now = now or utcnow()
    with _conn() as c:
        return c.execute(
            "SELECT * FROM posts WHERE status='scheduled' AND scheduled_for <= ? ORDER BY scheduled_for",
            (iso(now),),
        ).fetchall()


def list_posts() -> list[dict]:
    with _conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM posts ORDER BY id DESC")]


def mark_published(post_id: int, external_id: str) -> None:
    with _conn() as c:
        c.execute("UPDATE posts SET status='published', external_id=? WHERE id=?", (external_id, post_id))


def mark_failed(post_id: int, error: str) -> None:
    with _conn() as c:
        c.execute("UPDATE posts SET status='failed', error=? WHERE id=?", (error, post_id))


def save_token(platform: str, data: dict) -> None:
    with _conn() as c:
        c.execute("INSERT OR REPLACE INTO tokens (platform, data) VALUES (?,?)", (platform, json.dumps(data)))


def get_token(platform: str) -> dict | None:
    with _conn() as c:
        row = c.execute("SELECT data FROM tokens WHERE platform=?", (platform,)).fetchone()
        return json.loads(row["data"]) if row else None
