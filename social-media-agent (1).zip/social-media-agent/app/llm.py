"""Draft writer. Uses Claude (with tool calling) if a key is set, else a deterministic mock."""
import os

from . import config
from .tools import TOOL_MAP, check_char_limit, suggest_hashtags

SYSTEM = (
    "You are a social media copywriter. Write ONE post for the given platform and tone. "
    "Use the check_char_limit tool to verify length and suggest_hashtags for hashtags. "
    "If feedback is provided, revise the previous draft accordingly. Reply with the post text only."
)


def _text(content) -> str:
    if isinstance(content, list):
        return "".join(b.get("text", "") for b in content if isinstance(b, dict)).strip()
    return str(content).strip()


def _mock(topic, platform, tone, feedback, previous) -> str:
    tags = suggest_hashtags.invoke({"topic": topic})
    openers = {
        "professional": "Excited to share an update:",
        "casual": "Okay, quick one:",
        "witty": "Plot twist:",
    }
    base = previous.split(" #")[0] if previous else f"{openers.get(tone, 'Update:')} {topic}."
    if feedback:
        fb = feedback.lower()
        if "short" in fb:
            base = base.split(".")[0] + "."
        if "emoji" in fb:
            base += " 🚀"
        if "call to action" in fb or "cta" in fb:
            base += " Follow along to learn more!"
    return f"{base} {tags}".strip()


def generate_draft(topic: str, platform: str, tone: str, feedback: str = "", previous: str = "") -> str:
    key = os.getenv("ANTHROPIC_API_KEY")
    if not key:
        return _mock(topic, platform, tone, feedback, previous)

    from langchain_anthropic import ChatAnthropic
    from langchain_core.messages import HumanMessage, SystemMessage, ToolMessage

    llm = ChatAnthropic(model=config.LLM_MODEL, temperature=0.7).bind_tools([check_char_limit, suggest_hashtags])
    prompt = f"Topic: {topic}\nPlatform: {platform}\nTone: {tone}"
    if feedback:
        prompt += f"\nPrevious draft: {previous}\nReviewer feedback: {feedback}"
    msgs = [SystemMessage(SYSTEM), HumanMessage(prompt)]
    for _ in range(4):  # tool-calling loop
        resp = llm.invoke(msgs)
        msgs.append(resp)
        if not resp.tool_calls:
            return _text(resp.content)
        for call in resp.tool_calls:
            out = TOOL_MAP[call["name"]].invoke(call["args"])
            msgs.append(ToolMessage(content=str(out), tool_call_id=call["id"]))
    return _text(msgs[-1].content)
