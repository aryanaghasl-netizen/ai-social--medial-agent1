"""Twitter/X OAuth 2.0 Authorization Code flow with PKCE (+ token refresh)."""
import base64
import hashlib
import os
import secrets
import time
from urllib.parse import urlencode

import requests

from . import db

AUTH_URL = "https://twitter.com/i/oauth2/authorize"
TOKEN_URL = "https://api.twitter.com/2/oauth2/token"
SCOPES = "tweet.read tweet.write users.read offline.access"
_STATES: dict[str, str] = {}   # state -> code_verifier (use Redis/DB in production)


def _client():
    cid = os.getenv("TWITTER_CLIENT_ID", "")
    secret = os.getenv("TWITTER_CLIENT_SECRET", "")
    return cid, (requests.auth.HTTPBasicAuth(cid, secret) if secret else None)


def build_auth_url() -> str:
    verifier = secrets.token_urlsafe(64)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    state = secrets.token_urlsafe(16)
    _STATES[state] = verifier
    params = {
        "response_type": "code",
        "client_id": os.getenv("TWITTER_CLIENT_ID", ""),
        "redirect_uri": os.getenv("OAUTH_REDIRECT_URI", "http://localhost:8000/auth/twitter/callback"),
        "scope": SCOPES,
        "state": state,
        "code_challenge": challenge,
        "code_challenge_method": "S256",
    }
    return f"{AUTH_URL}?{urlencode(params)}"


def _store(tok: dict) -> dict:
    tok["expires_at"] = time.time() + tok.get("expires_in", 7200) - 60
    db.save_token("twitter", tok)
    return tok


def exchange_code(code: str, state: str) -> dict:
    verifier = _STATES.pop(state, None)
    if not verifier:
        raise ValueError("Unknown or expired OAuth state")
    cid, auth = _client()
    r = requests.post(TOKEN_URL, auth=auth, timeout=15, data={
        "grant_type": "authorization_code", "code": code, "client_id": cid,
        "redirect_uri": os.getenv("OAUTH_REDIRECT_URI", "http://localhost:8000/auth/twitter/callback"),
        "code_verifier": verifier,
    })
    r.raise_for_status()
    return _store(r.json())


def get_valid_token() -> str:
    tok = db.get_token("twitter")
    if not tok:
        raise RuntimeError("Twitter not connected. Visit /auth/twitter/login first.")
    if time.time() >= tok.get("expires_at", 0):
        cid, auth = _client()
        r = requests.post(TOKEN_URL, auth=auth, timeout=15, data={
            "grant_type": "refresh_token", "refresh_token": tok["refresh_token"], "client_id": cid})
        r.raise_for_status()
        tok = _store(r.json())
    return tok["access_token"]
