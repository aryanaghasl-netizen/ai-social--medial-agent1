"""LangChain tools the agent can call (tool calling)."""
import json
import re
from datetime import timedelta

from langchain_core.tools import tool

from .db import iso, utcnow

LIMITS = {"twitter": 280, "linkedin": 3000, "mastodon": 500}
BEST_HOURS_UTC = {"twitter": [9, 13, 17], "linkedin": [7, 12], "mastodon": [10, 18]}


@tool
def check_char_limit(text: str, platform: str) -> str:
    """Check whether a post fits the platform's character limit. Returns JSON."""
    limit = LIMITS.get(platform.lower(), 280)
    return json.dumps({"length": len(text), "limit": limit, "ok": len(text) <= limit})


@tool
def suggest_hashtags(topic: str) -> str:
    """Suggest up to 3 relevant hashtags for a topic."""
    words = [w for w in re.findall(r"[A-Za-z0-9]+", topic) if len(w) > 3][:3]
    return " ".join("#" + w.capitalize() for w in words) or "#Update"


@tool
def get_best_posting_time(platform: str) -> str:
    """Return the next recommended posting time (ISO-8601 UTC) for a platform."""
    now = utcnow()
    for day in (0, 1):
        for hour in BEST_HOURS_UTC.get(platform.lower(), [9]):
            slot = (now + timedelta(days=day)).replace(hour=hour, minute=0, second=0, microsecond=0)
            if slot > now:
                return iso(slot)
    return iso(now + timedelta(hours=1))


TOOLS = [check_char_limit, suggest_hashtags, get_best_posting_time]
TOOL_MAP = {t.name: t for t in TOOLS}
