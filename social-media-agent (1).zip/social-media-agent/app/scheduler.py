"""Cron-style automation: every minute, publish approved posts whose time has come."""
import logging
import time

from . import db
from .platforms import get_publisher

log = logging.getLogger("scheduler")


def publish_due() -> list[dict]:
    done = []
    for row in db.due_posts():
        try:
            ext = get_publisher(row["platform"]).publish(row["content"])
            db.mark_published(row["id"], ext)
            done.append({"id": row["id"], "platform": row["platform"], "external_id": ext})
            log.info("published #%s on %s", row["id"], row["platform"])
        except Exception as exc:  # keep the queue moving
            db.mark_failed(row["id"], str(exc))
            log.error("failed #%s: %s", row["id"], exc)
    return done


def start_scheduler(blocking: bool = False):
    from apscheduler.schedulers.background import BackgroundScheduler
    from apscheduler.triggers.cron import CronTrigger

    sched = BackgroundScheduler(timezone="UTC")
    sched.add_job(publish_due, CronTrigger(minute="*"), id="publish_due", max_instances=1)
    sched.start()
    if blocking:
        try:
            while True:
                time.sleep(1)
        except (KeyboardInterrupt, SystemExit):
            sched.shutdown()
    return sched
