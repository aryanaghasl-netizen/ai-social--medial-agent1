import os
import tempfile
from datetime import timedelta

import pytest

os.environ.pop("ANTHROPIC_API_KEY", None)
_tmp = tempfile.mkdtemp()
os.environ["DB_PATH"] = os.path.join(_tmp, "t.db")
os.environ["PUBLISHED_LOG"] = os.path.join(_tmp, "pub.log")

from app import config, db, service  # noqa: E402
from app.scheduler import publish_due  # noqa: E402
from app.tools import check_char_limit  # noqa: E402

config.DB_PATH = os.environ["DB_PATH"]
config.PUBLISHED_LOG = os.environ["PUBLISHED_LOG"]


def test_char_limit_tool():
    assert '"ok": false' in check_char_limit.invoke({"text": "x" * 300, "platform": "twitter"})


def test_pauses_for_human_then_schedules_and_publishes():
    past = db.iso(db.utcnow() - timedelta(seconds=1))
    tid, pending, result = service.start_post("Testing the agent", "twitter", scheduled_for=past)
    assert pending and "draft" in pending and result.get("status") == "drafted"   # paused at approval
    assert db.list_posts() == []                                                   # nothing scheduled yet

    pending, _ = service.submit_decision(tid, "revise", "add an emoji")
    assert "🚀" in pending["draft"]                                                # loop back works

    pending, result = service.submit_decision(tid, "approve")
    assert pending is None and result["status"] == "scheduled"

    published = publish_due()
    assert len(published) == 1
    assert db.list_posts()[0]["status"] == "published"
    assert "Testing the agent" in open(config.PUBLISHED_LOG, encoding="utf-8").read()


def test_reject_never_schedules():
    before = len(db.list_posts())
    tid, _, _ = service.start_post("Bad idea", "twitter")
    _, result = service.submit_decision(tid, "reject")
    assert result["status"] == "rejected" and len(db.list_posts()) == before
