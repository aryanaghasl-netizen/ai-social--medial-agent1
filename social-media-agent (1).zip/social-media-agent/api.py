"""FastAPI server: approval inbox + OAuth + background scheduler.   Run: uvicorn api:app --reload"""
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from fastapi.responses import RedirectResponse
from pydantic import BaseModel

from app import db, oauth, service
from app.scheduler import start_scheduler


@asynccontextmanager
async def lifespan(app: FastAPI):
    sched = start_scheduler()
    yield
    sched.shutdown()


app = FastAPI(title="AI Social Media Agent", lifespan=lifespan)


class NewPost(BaseModel):
    topic: str
    platform: str = "twitter"
    tone: str = "professional"
    scheduled_for: str | None = None   # ISO-8601 UTC; default = best posting time


class Decision(BaseModel):
    action: str                        # approve | revise | reject
    feedback: str = ""
    edited_draft: str | None = None


@app.post("/posts")
def create_post(body: NewPost):
    thread_id, pending, _ = service.start_post(body.topic, body.platform, body.tone, body.scheduled_for)
    return {"thread_id": thread_id, "awaiting_approval": pending}


@app.get("/posts/pending")
def pending():
    return service.PENDING


@app.post("/posts/{thread_id}/decision")
def decide(thread_id: str, body: Decision):
    if body.action not in {"approve", "revise", "reject"}:
        raise HTTPException(400, "action must be approve | revise | reject")
    if thread_id not in service.PENDING:
        raise HTTPException(404, "No pending post with that id")
    pending_, result = service.submit_decision(thread_id, body.action, body.feedback, body.edited_draft)
    return {"status": result.get("status"), "scheduled_for": result.get("scheduled_for"),
            "awaiting_approval": pending_}


@app.get("/queue")
def queue():
    return db.list_posts()


@app.get("/auth/twitter/login")
def twitter_login():
    return RedirectResponse(oauth.build_auth_url())


@app.get("/auth/twitter/callback")
def twitter_callback(code: str, state: str):
    try:
        oauth.exchange_code(code, state)
    except Exception as exc:
        raise HTTPException(400, str(exc))
    return {"connected": "twitter"}
